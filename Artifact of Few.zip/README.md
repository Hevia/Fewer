# Artifact of Few

Artifact of Few is still early in development.

The goal with Artifact of Few is to reduce the amount of monsters in active play. I made this mod so older PCs don't drop to 3 FPS when playing with huge mod lists. 

Monster experience, and gold rewards are also buffed to compensate for less monsters present at a time. 

You can file issues on discord in the #tech-support channel by @ing me (username: Buns) or on Github. Please include a log!

## TODO:
- Custom icons (right now its still just the command icon)
- Balance tuning
- Make everything configurable.
- Add a 2nd artifact that operates similar to Few, but increases Elite spawn rates.
- proper project deps
- Better README
- Better Thunderstore icon too...

## Credit
- Thanks to swuff and HIFU for the idea to use Team catalog to reduce the overall monster cap.
- Thanks to Starstorm team and swuff for the Typhoon code I based this mod on.

# Changelog
- 1.0.0 : Inital release